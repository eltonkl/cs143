For project 1B, we decided to break the project into smaller
chunks based on each file. One person worked on create, load,
and queries while the other person worked on the rest.