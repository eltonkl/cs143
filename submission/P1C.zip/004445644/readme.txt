Our project submission meets all of the criterias set in the specification online.
We have several pages of "add" that lets user add contents to the database.
We also implement the browsing features, to which users can access by searching through the search box.

In splitting up the work, Anthony complete the add content pages, while Elton did
the search functionality and browsing pages. Anthony generated the test files from Selenium,
while Elton executed them to make sure the run properly.

We feel that our team collaboration was really good.

