For project 2A, our project submission meets all of the criterias 
set in the specification online. We did not make any improvement to
the implementation of LOAD command.

Emails:
Yu-Kuan (Anthony) Lai: yukuan.anthony.lai@gmail.com
Elton Leong: eltonleong@ucla.edu
