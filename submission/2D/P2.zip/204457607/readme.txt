For project 2D, our project submission meets all of the criteria
set in the specification online. We did not make any improvement to
the implementation of LOAD. We also use climits.h to get the
definitions for INT_MIN and INT_MAX.

Emails:
Yu-Kuan (Anthony) Lai: yukuan.anthony.lai@gmail.com
Elton Leong: eltonleong@ucla.edu
