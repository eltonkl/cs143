For project 1A, since this is a small project and 
neither of us know PHP, we decided to do pair programming
and work together on one person's laptop.